@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3 is required. Install it from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
start "Design Help server" /min py -m http.server 8080
 timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8080/app/
echo Design Help is running at http://127.0.0.1:8080/app/
echo Close the server window to stop the prototype.
