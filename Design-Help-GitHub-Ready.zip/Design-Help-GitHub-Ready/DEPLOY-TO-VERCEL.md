# Deploy Design Help to Vercel through GitHub

1. Push this project to a GitHub repository. The repository root must contain `index.html`, `app/`, `screens/`, `manifest.webmanifest`, and `sw.js`.
2. Sign in to Vercel.
3. Select **Add New → Project** and import the GitHub repository.
4. Use **Other** as the framework preset. This is a static HTML/CSS/JavaScript project; there is no build command.
5. Keep the root directory at `./`. Leave the output directory empty/default.
6. Click **Deploy**.
7. Open the generated Vercel URL. The landing page links to the interactive app and the 88-screen gallery.

When Vercel is connected to GitHub, pushes to the production branch can trigger deployments automatically. See the official guide: https://vercel.com/docs/git/vercel-for-github

## PWA/mobile install

Use the HTTPS Vercel URL:
- Android: Chrome menu → Install app / Add to Home screen.
- iPhone: Safari Share → Add to Home Screen.

## Data warning

Deploying this static prototype does not add cloud accounts or shared data. All prototype records are local to each visitor's browser. Connect a secure backend before using it with real clients.
