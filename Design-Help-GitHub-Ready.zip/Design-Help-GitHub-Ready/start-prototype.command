#!/bin/bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it from https://www.python.org/downloads/macos/"
  read -r -p "Press Return to close..."
  exit 1
fi

PORT=${DH_PORT:-8080}
for attempt in $(seq 1 30); do
  if ! lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; then
    break
  fi
  PORT=$((PORT + 1))
done

URL="http://127.0.0.1:${PORT}/app/"
echo "
Starting Design Help..."
echo "Opening ${URL}"
echo "Keep this window open while you use the prototype. Press Control+C to stop.
"
python3 -m http.server "$PORT" --bind 127.0.0.1 >/tmp/design-help-http.log 2>&1 &
SERVER_PID=$!
cleanup(){ kill "$SERVER_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
sleep 1
open "$URL" 2>/dev/null || echo "Open this address in your browser: ${URL}"
wait "$SERVER_PID"
