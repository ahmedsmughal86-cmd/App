// App settings. Edit before you deploy.
// adminPin: the PIN Ahmed types on the "Admin sign in" screen.
// IMPORTANT: this runs in the browser, so anyone can read it. It is a convenience
// lock for a demo, not real security. For real accounts, connect a backend (see README).
window.DH_CONFIG = {
  adminPin: "1234"
};
