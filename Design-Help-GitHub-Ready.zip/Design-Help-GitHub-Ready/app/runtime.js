// Standalone runtime. Replaces the Claude Artifacts runtime (db, user, assets)
// with a browser-only version so the app works on its own.
//  - Requests, messages and settings live in localStorage (this browser only).
//  - Attached files live in IndexedDB (this browser only).
//  - Two tabs in the same browser stay in sync, so you can test client and admin side by side.
// To make it multi-user, replace this file with an adapter for a real backend (see README).
(function () {
  "use strict";
  window.DH_STANDALONE = true;
  window.DH_BLOBS = window.DH_BLOBS || {};
  var LS = window.localStorage, KEY = "dh_standalone_db_v1", listeners = new Set();

  function read() { try { return JSON.parse(LS.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function write(d) { LS.setItem(KEY, JSON.stringify(d)); }
  function rid() { return Array.from(crypto.getRandomValues(new Uint8Array(16))).map(function (b) { return b.toString(16).padStart(2, "0"); }).join(""); }
  function fire() { listeners.forEach(function (fn) { fn(); }); }

  // ---- files (IndexedDB) ----
  function idb() {
    return new Promise(function (res, rej) {
      var r = indexedDB.open("dh_files", 1);
      r.onupgradeneeded = function () { r.result.createObjectStore("files", { keyPath: "id" }); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }
  function preload() {
    return idb().then(function (d) {
      return new Promise(function (res, rej) {
        var q = d.transaction("files").objectStore("files").getAll();
        q.onsuccess = function () { q.result.forEach(function (f) { if (!DH_BLOBS[f.id]) DH_BLOBS[f.id] = URL.createObjectURL(f.blob); }); res(); };
        q.onerror = function () { rej(q.error); };
      });
    }).catch(function () {});
  }
  var ready = preload();
  function notify() { preload().then(fire); }
  addEventListener("storage", function (e) { if (e.key === KEY || e.key === "dh_blob_tick") notify(); });

  // ---- db ----
  var db = {
    collection: function (name) {
      var order = null, lim = 1e9;
      var q = {
        orderBy: function (f, dir) { order = [f, dir || "asc"]; return q; },
        limit: function (n) { lim = n; return q; },
        onSnapshot: function (cb) {
          function run() {
            var d = read()[name] || {};
            var docs = Object.keys(d).map(function (id) { return { id: id, data: function () { return d[id]; } }; });
            if (order) docs.sort(function (a, b) {
              var x = a.data()[order[0]] || 0, y = b.data()[order[0]] || 0;
              return (x < y ? -1 : x > y ? 1 : 0) * (order[1] === "desc" ? -1 : 1);
            });
            cb({ docs: docs.slice(0, lim) });
          }
          listeners.add(run); ready.then(run);
          return function () { listeners.delete(run); };
        },
        add: function (data) {
          return new Promise(function (res) {
            var all = read(); all[name] = all[name] || {};
            var id = rid().slice(0, 20); all[name][id] = data; write(all); fire(); res({ id: id });
          });
        }
      };
      return q;
    },
    doc: function (path) {
      var p = path.split("/"), c = p[0], id = p[1];
      return {
        update: function (patch) {
          return new Promise(function (res, rej) {
            var all = read(); all[c] = all[c] || {};
            if (!all[c][id]) return rej(new Error("Document not found"));
            Object.assign(all[c][id], patch); write(all); fire(); res();
          });
        },
        set: function (data) {
          return new Promise(function (res) { var all = read(); all[c] = all[c] || {}; all[c][id] = data; write(all); fire(); res(); });
        },
        onSnapshot: function (cb) {
          function run() { var v = (read()[c] || {})[id]; cb({ exists: v !== undefined, data: function () { return v; } }); }
          listeners.add(run); ready.then(run);
          return function () { listeners.delete(run); };
        }
      };
    }
  };

  // ---- user ----
  var uid = LS.getItem("dh_uid"); if (!uid) { uid = rid(); LS.setItem("dh_uid", uid); }
  var user = {
    id: function () { return Promise.resolve(uid); },
    isOwner: function () { return LS.getItem("dh_admin_ok") === "1"; }
  };

  // ---- assets ----
  var MAX = 20 * 1048576;
  var assets = {
    upload: function (file) {
      return new Promise(function (res, rej) {
        if (file.size > MAX) return rej({ code: "too_large", message: "File is over 20 MB." });
        var ok = /^(image\/|video\/|application\/pdf|text\/)/.test(file.type) || /\.(csv|md|json|txt)$/i.test(file.name);
        if (!ok) return rej({ code: "unsupported_type", message: "Unsupported file type." });
        var id = rid();
        idb().then(function (d) {
          var tx = d.transaction("files", "readwrite");
          tx.objectStore("files").put({ id: id, name: file.name, type: file.type, blob: file });
          tx.oncomplete = function () {
            DH_BLOBS[id] = URL.createObjectURL(file);
            LS.setItem("dh_blob_tick", String(Date.now()));
            res({ id: id, url: DH_BLOBS[id], sizeBytes: file.size, contentType: file.type || "application/octet-stream" });
          };
          tx.onerror = function () { rej({ code: "quota_or_state", message: "Could not store the file." }); };
        }).catch(function () { rej({ code: "quota_or_state", message: "Could not store the file." }); });
      });
    }
  };

  window.claude = { use: function (name) { return Promise.resolve({ db: db, user: user, assets: assets }[name] || null); } };
})();
