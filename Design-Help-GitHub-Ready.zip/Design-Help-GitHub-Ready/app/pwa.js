(function () {
  "use strict";
  var deferredPrompt = null;
  var root = document.documentElement;
  var standalone = window.matchMedia && window.matchMedia("(display-mode: standalone)").matches;
  var iosStandalone = window.navigator.standalone === true;
  var nativeApp = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === "function" && window.Capacitor.isNativePlatform());
  var ua = (navigator.userAgent || "").toLowerCase();
  var isIOS = /iphone|ipad|ipod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

  if (nativeApp) root.classList.add("pwa-native");
  if (standalone || iosStandalone) root.classList.add("pwa-standalone");
  if (isIOS && !iosStandalone && !nativeApp) root.classList.add("pwa-ios-installable");

  if ("serviceWorker" in navigator && !nativeApp && location.protocol !== "file:") {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("../sw.js", { scope: "../" }).catch(function (err) {
        console.warn("Design Help offline support could not be enabled:", err);
      });
    });
  }

  window.addEventListener("beforeinstallprompt", function (event) {
    event.preventDefault();
    deferredPrompt = event;
    root.classList.add("pwa-install-available");
  });

  window.addEventListener("appinstalled", function () {
    deferredPrompt = null;
    root.classList.remove("pwa-install-available", "pwa-ios-installable");
    root.classList.add("pwa-standalone");
  });

  document.addEventListener("click", async function (event) {
    var button = event.target && event.target.closest ? event.target.closest("[data-install-app]") : null;
    if (!button) return;
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try {
        var choice = await deferredPrompt.userChoice;
        if (choice && choice.outcome === "accepted") root.classList.remove("pwa-install-available");
      } catch (e) { console.warn("Install prompt was not completed:", e); }
      deferredPrompt = null;
      return;
    }
    if (isIOS) {
      alert("To add Design Help to your iPhone: tap the Share button in Safari, choose ‘Add to Home Screen’, turn on ‘Open as Web App’ if shown, then tap Add.");
    } else {
      alert("To install Design Help, open this page in Chrome or Edge and choose ‘Install app’ or ‘Add to Home screen’ from the browser menu.");
    }
  });
})();
