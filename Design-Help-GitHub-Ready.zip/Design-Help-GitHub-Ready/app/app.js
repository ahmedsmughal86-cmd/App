// Design Help app logic (vanilla JS, no dependencies).
// Talks to window.claude.use('db'|'user'|'assets'), which runtime.js provides.
const LB={new:"Sent",accepted:"Proposal sent",designing:"Designing",delivered:"Ready to review",solved:"Solved"};
const ORD=["new","accepted","designing","delivered","solved"];
const CATS=["UI design","UX audit","Mobile app","Web design","Research","Design system","Motion & animation","Figma review","Accessibility audit"];
const QUICK=["Can you send the current screens?","Your proposal is ready to review.","Let’s book a quick call."];
const SLOTS=["Tomorrow 11:30","Tomorrow 16:30","In 2 days 11:30"];
let db=null,me="local",owner=false,view="client",reqs=[],open=null,tab="home",filter="all",avail=true,prop=false,intro=false,formOpen=false;
let assets=null,up=false;
let draft={cat:"",text:"",urgency:"This week",name:"",link:""};
const ls={get(k){try{return localStorage.getItem(k)}catch(x){return null}},set(k,v){try{localStorage.setItem(k,v)}catch(x){}}};
draft.name=ls.get("dh_name")||"";intro=false;
let session=ls.get("dh_role")==="admin"?"admin":ls.get("dh_role")==="client"?"client":"",outConfirm=false,justOut=false;
if(session==="admin"){view="admin";tab="inbox"}
const $=document.getElementById("app");
const e=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const isUrl=u=>/^https?:\/\/[^\s]+$/i.test(u||"");
const tagCls=s=>({solved:"done",delivered:"rev",accepted:"pk",designing:"og"})[s]||"";
const PCT={new:15,accepted:35,designing:60,delivered:85,solved:100};
const ring=s=>'<div class="ring" style="background:conic-gradient(var(--a) '+PCT[s]*3.6+'deg,var(--s2) 0)"><em>'+PCT[s]+"%</em></div>";
const ACTS=[
  ["l","Fix a UX problem","Find friction and drop-offs","UX audit","⌁"],
  ["w","Design an app or site","Mobile, web and responsive UI","Web design","▣"],
  ["p","Review my design","Get clear, actionable feedback","UI design","★"],
  ["w","Figma design review","Feedback on your Figma file","Figma review","F"],
  ["p","Motion & animation","Micro-interactions and transitions","Motion & animation","↗"],
  ["l","Build a design system","Reusable components and styles","Design system","◈"],
  ["w","Accessibility audit","Contrast, type and usability","Accessibility audit","◎"],
  ["p","Research & user flows","Understand users and journeys","Research","⌘"],
  ["w","Something else","Tell Ahmed what you need","","?"]
];
const WORKS=[
  {id:"mobile-flow",title:"Mobile app experience",type:"App design",desc:"A focused mobile journey with clear steps and polished interface patterns.",screen:"V3B.html",symbol:"▣",tone:"lime"},
  {id:"ux-journey",title:"UX journey & screen flow",type:"UX strategy",desc:"Map the user journey, identify friction and make the next action obvious.",screen:"WUF.html",symbol:"⌁",tone:"purple"},
  {id:"design-system",title:"Design system foundations",type:"Design system",desc:"A reusable visual language for consistent product experiences.",screen:"DS1.html",symbol:"◈",tone:"lime"},
  {id:"admin-dashboard",title:"Admin dashboard concept",type:"Dashboard UI",desc:"A structured workspace for managing requests, people and progress.",screen:"Admin2.html",symbol:"▦",tone:"purple"},
  {id:"client-chat",title:"Client communication flow",type:"Product UX",desc:"A simple conversation and status flow for a service experience.",screen:"V3F.html",symbol:"✉",tone:"lime"},
  {id:"ux-review",title:"Design review experience",type:"Review flow",desc:"A clear handoff for feedback, delivery and final approval.",screen:"XV4.html",symbol:"✦",tone:"purple"}
];
const SAVED_KEY="dh_saved_designs_v1", NOTICES_KEY="dh_notifications_v1";
const EX=["Users drop off at checkout","My app looks outdated","People can’t find the main feature"];
const ago=t=>{if(!t)return"";const m=Math.round((Date.now()-t)/6e4);return m<1?"now":m<60?m+"m":m<1440?Math.round(m/60)+"h":Math.round(m/1440)+"d"};
const isAdmin=()=>(owner||!db)&&view==="admin";
const role=()=>isAdmin()?"ahmed":"client";
function toast(t){const d=document.createElement("div");d.textContent=t;d.className="toastpop";document.body.append(d);setTimeout(()=>d.remove(),3000)}
function readJson(key,fallback){try{const v=JSON.parse(ls.get(key)||"null");return v??fallback}catch(x){return fallback}}
function notices(){return readJson(NOTICES_KEY,[])}
function pushNotice(to,title,body,requestId){const n=notices();n.unshift({id:"n"+Date.now()+Math.random().toString(16).slice(2,6),to,title,body,requestId:requestId||null,at:Date.now(),read:false});ls.set(NOTICES_KEY,JSON.stringify(n.slice(0,60)))}
function myNotices(){const who=session==="admin"?"admin":"client";return notices().filter(n=>n.to===who).sort((a,b)=>b.at-a.at)}
function unreadNoticeCount(){return myNotices().filter(n=>!n.read).length}
function markAllNoticesRead(){const who=session==="admin"?"admin":"client",n=notices().map(x=>x.to===who?{...x,read:true}:x);ls.set(NOTICES_KEY,JSON.stringify(n))}
function savedDesigns(){return readJson(SAVED_KEY,[])}
function toggleSaved(id){const s=savedDesigns();const exists=s.includes(id);ls.set(SAVED_KEY,JSON.stringify(exists?s.filter(x=>x!==id):[...s,id]));toast(exists?"Removed from saved designs":"Design saved ✓");render()}
async function save(id,patch){const r=reqs.find(x=>x.id===id);Object.assign(r,patch);render();if(db)try{await db.doc("requests/"+id).update(patch)}catch(err){toast("Couldn’t save. Check your connection.")}}
function say(id,from,text,extra={}){const r=reqs.find(x=>x.id===id);ls.set("dh_seen_"+id,Date.now());const other=from==="ahmed"?"client":"admin";pushNotice(other,from==="ahmed"?"Ahmed sent an update":"New client message",(text||"A file was shared.").slice(0,110),id);return save(id,{messages:[...(r.messages||[]),{from,text,at:Date.now()}],updatedAt:Date.now(),...extra})}
async function create(){
  const data={cat:draft.cat,problem:draft.text.trim(),urgency:draft.urgency,name:draft.name.trim()||"Client",owner:me,status:"new",createdAt:Date.now(),updatedAt:Date.now(),messages:[{from:"system",text:"Request sent. Ahmed usually replies within a day.",at:Date.now()}]};
  if(isUrl(draft.link.trim()))data.link=draft.link.trim();
  ls.set("dh_name",draft.name);let id="l"+Date.now();
  if(db)try{id=(await db.collection("requests").add(data)).id}catch(err){return toast("Couldn’t send. Please try again.")}
  else reqs.unshift({id,...data});
  pushNotice("admin","New client request",(data.cat||"Design request")+" · "+data.name,id);
  draft.cat="";draft.text="";draft.link="";formOpen=false;openReq(id)
}
const CLIP='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11l-9 9a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/></svg>';
function msgBody(m){
  let h=e(m.text||"");const f=m.file;
  if(f&&/^[0-9a-f]{32}$/.test(f.id||"")){
    const u=(window.DH_BLOBS&&DH_BLOBS[f.id])||"/_blob/"+f.id,sz=+f.size||0,kb=sz>1048576?(sz/1048576).toFixed(1)+" MB":Math.max(1,Math.round(sz/1024))+" KB";
    if(/^image\//.test(f.type||"")&&!/svg/.test(f.type))h+='<a href="'+u+'" target="_blank" rel="noopener noreferrer"><img src="'+u+'" alt="'+e(f.name)+'" style="max-width:100%;border-radius:12px;display:block;margin-bottom:8px"></a>';
    h+='<a href="'+u+'" target="_blank" rel="noopener noreferrer">'+e(f.name)+" · "+kb+"</a>";
  }
  return h;
}
async function attach(f){
  if(!assets||!f||up)return;
  if(f.size>20*1048576)return toast("That file is over 20 MB.");
  up=true;render();
  try{
    const x=await assets.upload(f),r=reqs.find(q=>q.id===open);
    if(r){ls.set("dh_seen_"+open,Date.now());await save(open,{messages:[...(r.messages||[]),{from:role(),text:"",file:{id:x.id,name:f.name.slice(0,80),type:x.contentType,size:x.sizeBytes},at:Date.now()}],updatedAt:Date.now()})}
  }catch(err){const c=err&&err.code;toast(c==="unsupported_type"?"That file type isn’t supported. Try an image, PDF, video or text file.":c==="too_large"?"That file is over 20 MB.":"Upload failed. Please try again.")}
  up=false;render();
}
function openReq(id){open=id;prop=false;ls.set("dh_seen_"+id,Date.now());render();window.scrollTo(0,0)}
function unread(r){const m=(r.messages||[]).slice(-1)[0];return m&&m.from!=="system"&&m.from!==role()&&(r.updatedAt||0)>(+ls.get("dh_seen_"+r.id)||0)}
const stepper=s=>{const i=ORD.indexOf(s);return '<div class="steps" role="img" aria-label="Status: '+LB[s]+'">'+ORD.map((_,k)=>'<i class="'+(k<=i?"on":"")+'"></i>').join("")+"</div>"};
function list(rs,adm){
  if(!rs.length)return '<div class="empty"><h2>Nothing here yet</h2><p class="sub">'+(adm?"New client requests will show up here.":"Your requests and Ahmed’s replies will show up here.")+"</p></div>";
  return rs.map(r=>'<button class="card" data-open="'+e(r.id)+'"><div class="row between"><b>'+(unread(r)?'<span class="dot" aria-label="Unread"></span> ':"")+e(adm?r.name+" · ":"")+e(r.cat||"Request")+'</b><span class="tag '+tagCls(r.status)+'">'+LB[r.status]+'</span></div><div class="sub">'+e((r.problem||"").slice(0,90))+'</div><div class="sm">'+ago(r.updatedAt)+"</div></button>").join("");
}
function filters(){return '<div class="row" role="group" aria-label="Filter">'+[["all","All"],["open","Open"],["solved","Solved"]].map(([k,l])=>'<button class="chip '+(filter===k?"on":"")+'" data-filter="'+k+'">'+l+"</button>").join("")+"</div>"}
const flt=rs=>rs.filter(r=>filter==="all"||(filter==="solved")===(r.status==="solved"));
function thread(r,adm){
  const ms=(r.messages||[]).map(m=>'<div class="m '+(m.from==="system"?"sys":(m.from==="ahmed")===adm?"me":"")+'">'+msgBody(m)+"</div>").join("");
  let act="";
  if(adm){
    if(r.status==="new")act=prop?'<div class="card"><b>Send a proposal</b><input id="pr_price" aria-label="Price" placeholder="Price (e.g. $120)"><input id="pr_del" aria-label="Delivery" placeholder="Delivery (e.g. Friday)"><button class="btn" data-sendprop="1">Send proposal</button></div>':'<button class="btn" data-prop="1">Accept & send proposal</button>';
    else{const nx={designing:["delivered","Mark as delivered"]}[r.status];act=nx?'<button class="btn" data-status="'+nx[0]+'">'+nx[1]+"</button>":""}
    if(r.call&&!r.callOk)act='<div class="card"><b>Call requested: '+e(r.call)+'</b><button class="btn" data-callok="1">Confirm call</button></div>'+act;
    act+='<div class="row">'+QUICK.map((q,i)=>'<button class="chip" data-quick="'+i+'">'+e(q)+"</button>").join("")+"</div>";
  }else{
    if(r.status==="accepted"&&r.proposal)act='<div class="card"><b>Ahmed’s proposal</b><div class="row between"><span class="sub">Price</span><b>'+e(r.proposal.price)+'</b></div><div class="row between"><span class="sub">Delivery</span><b>'+e(r.proposal.delivery)+'</b></div><button class="btn" data-status="designing">Approve & start</button><p class="sm" style="margin:0">Payment is arranged directly with Ahmed.</p></div>';
    if(r.status==="delivered")act='<button class="btn" data-status="solved">Approve & finish</button><button class="btn sec" data-changes="1">Request changes</button>';
    if(r.status!=="solved"&&!r.call)act+='<div class="sm">Book a 30 min call</div><div class="row">'+SLOTS.map((s,i)=>'<button class="chip" data-slot="'+i+'">'+s+"</button>").join("")+"</div>";
    if(r.call)act+='<div class="card"><b>Call '+(r.callOk?"confirmed":"requested")+": "+e(r.call)+"</b></div>";
    if(r.status==="solved")act+=r.rating?'<p class="sub" style="text-align:center">You rated this '+r.rating+" of 5. Thank you!</p>":'<div class="card"><b>How did Ahmed do?</b><div class="stars">'+[1,2,3,4,5].map(n=>'<button data-rate="'+n+'" aria-label="'+n+' stars">★</button>').join("")+"</div></div>";
  }
  const input=r.status==="solved"?"":'<form class="send" data-send="1">'+(assets?'<button type="button" class="attach" data-attach="1" aria-label="Attach a file"'+(up?" disabled":"")+">"+(up?"…":CLIP)+"</button>":"")+'<input id="msg" aria-label="Message" placeholder="Write a message" autocomplete="off"><button class="btn" aria-label="Send">➤</button></form>'+(assets?'<input type="file" id="file" hidden accept="image/*,application/pdf,video/*,.csv,.md,.json,.txt"><p class="sm" style="margin:0;text-align:center">Attach images, PDFs, video or text files up to 20 MB.</p>':"");
  const lk=r.link?'<a href="'+e(r.link)+'" target="_blank" rel="noopener noreferrer">Open attached link</a>':"";
  return '<div class="row"><button class="back" data-back="1" aria-label="Back">←</button><h2>'+e(r.cat||"Request")+'</h2><span class="tag '+tagCls(r.status)+'" style="margin-left:auto">'+LB[r.status]+"</span></div>"+stepper(r.status)+'<div class="card"><div class="sm">'+e(r.name)+" · "+e(r.urgency)+"</div><div>"+e(r.problem)+"</div>"+lk+'</div><div class="msgs">'+ms+"</div>"+act+input;
}
function home(mine){
  const cur=mine.find(r=>r.status!=="solved"),unread=unreadNoticeCount();
  return '<div class="row between"><div><div class="sm">Your designer</div><h2>Ahmed Sheraz</h2></div><span class="tag '+(avail?"done":"rev")+'">'+(avail?"Available":"Busy right now")+"</span></div>"+
  (cur?'<button class="card active-card" data-open="'+e(cur.id)+'">'+ring(cur.status)+'<div style="flex:1"><div class="sm">Your active request</div><b>'+e(cur.cat||"Request")+'</b><div class="sm">'+LB[cur.status]+"</div></div><span>→</span></button>":"")+ 
  '<div class="home-intro"><span class="sticker">Replies within about a day</span><h1 style="font-size:36px">What do you <em class="hl">need</em> today?</h1><p class="sub">Choose a service and let’s make your next idea happen.</p></div>'+ 
  '<div class="section-title"><h2>Explore services</h2><span class="sm">'+ACTS.length+' ways to get help</span></div><div class="service-grid">'+
  ACTS.map((a,i)=>'<button class="act compact '+a[0]+'" data-act="'+i+'"><i>'+a[4]+'</i><div><b>'+a[1]+'</b><span>'+a[2]+'</span></div></button>').join("")+ 
  '</div><div class="section-title"><h2>Discover Design Help</h2><span class="sm">Your creative workspace</span></div>'+ 
  '<button class="feature-card portfolio-feature" data-page="portfolio"><span class="feature-icon">✦</span><span class="feature-copy"><b>Explore the portfolio</b><small>Browse selected UI, UX and product design work</small></span><strong>→</strong></button>'+ 
  '<div class="feature-grid"><button class="feature-card" data-tab="saved"><span class="feature-icon lime-icon">♡</span><span class="feature-copy"><b>Saved designs</b><small>Keep useful screens close</small></span><strong>→</strong></button><button class="feature-card" data-tab="updates"><span class="feature-icon purple-icon">◌</span><span class="feature-copy"><b>Notifications</b><small>'+unread+' unread update'+(unread===1?'':'s')+'</small></span><strong>→</strong></button></div>';
}
function workCard(w,withSave=true){const saved=savedDesigns().includes(w.id);return '<article class="work-card"><div class="work-thumb '+w.tone+'"><span>'+w.symbol+'</span><small>'+w.type+'</small></div><div class="work-content"><div class="row between"><b>'+w.title+'</b>'+(withSave?'<button class="save-btn '+(saved?'saved':'')+'" data-save-design="'+w.id+'" aria-label="'+(saved?'Remove saved design':'Save design')+'">'+(saved?'♥':'♡')+'</button>':'')+'</div><p class="sub">'+w.desc+'</p><a class="text-link" href="../screens/'+w.screen+'" target="_blank" rel="noopener noreferrer">Open screen concept ↗</a></div></article>'}
function portfolioPage(){return '<div class="page-heading"><span class="eyebrow">Selected work</span><h1>Design <b>portfolio</b></h1><p class="sub">Explore interface concepts and product experiences from the Design Help screen library.</p></div><div class="section-title"><h2>Featured explorations</h2><span class="sm">6 concepts</span></div><div class="work-grid">'+WORKS.map(w=>workCard(w)).join('')+'</div><div class="card external-links"><b>More work by Ahmed</b><p class="sub">Explore additional design work and experiments.</p><a href="https://www.behance.net/ahmeeroaster" target="_blank" rel="noopener noreferrer">Behance portfolio ↗</a><a href="https://dribbble.com/AHMEDSHER99" target="_blank" rel="noopener noreferrer">Dribbble profile ↗</a></div><button class="btn sec" data-tab="home">Back to home</button>'}
function savedPage(){const ids=savedDesigns(),items=WORKS.filter(w=>ids.includes(w.id));return '<div class="page-heading"><span class="eyebrow">Your collection</span><h1>Saved <b>designs</b></h1><p class="sub">Bookmark useful screen concepts and come back to them anytime.</p></div>'+(items.length?'<div class="work-grid">'+items.map(w=>workCard(w)).join('')+'</div>':'<div class="empty-card"><div class="empty-symbol">♡</div><h2>No saved designs yet</h2><p class="sub">Explore the portfolio and tap the heart on a design to save it here.</p><button class="btn" data-page="portfolio">Explore portfolio</button></div>')+'<button class="btn sec" data-page="portfolio">Browse all designs</button>'}
function notificationsPage(){const items=myNotices();return '<div class="page-heading"><span class="eyebrow">Activity centre</span><h1>Notifi<b>cations</b></h1><p class="sub">Updates about requests, conversations and project progress.</p></div><div class="row between"><span class="sm">'+items.filter(n=>!n.read).length+' unread · '+items.length+' total</span>'+(items.some(n=>!n.read)?'<button class="chip" data-markread="1">Mark all read</button>':'')+'</div>'+(items.length?'<div class="notice-list">'+items.map(n=>'<button class="notice-card '+(n.read?'read':'unread')+'" data-open-notice="'+e(n.id)+'"><span class="notice-mark">'+(n.title.toLowerCase().includes('message')?'✉':'✦')+'</span><span class="notice-copy"><b>'+e(n.title)+'</b><small>'+e(n.body)+'</small><em>'+ago(n.at)+'</em></span>'+(n.read?'':'<i class="dot"></i>')+'</button>').join('')+'</div>':'<div class="empty-card"><div class="empty-symbol">◌</div><h2>You’re all caught up</h2><p class="sub">New request updates and replies will appear here.</p></div>')+'<button class="btn sec" data-tab="home">Back to home</button>'}
function formScreen(){
  const ok=draft.cat&&draft.text.trim().length>=20;
  return '<div class="row"><button class="back" data-closeform="1" aria-label="Back">←</button><h2>New request</h2></div><h1>Tell Ahmed what’s <b>broken</b></h1>'+
  '<div class="row" role="group" aria-label="Help type">'+CATS.map(c=>'<button class="chip '+(draft.cat===c?"on":"")+'" data-cat="'+c+'">'+c+"</button>").join("")+"</div>"+
  '<textarea id="txt" rows="4" aria-label="Describe the problem" placeholder="What’s going wrong? (at least 20 characters)">'+e(draft.text)+"</textarea>"+
  '<div class="sm">Not sure what to write? Tap an example:</div><div class="row">'+EX.map((x,i)=>'<button class="chip" data-ex="'+i+'">'+x+"</button>").join("")+"</div>"+
  '<input id="lk" aria-label="Link" placeholder="Link to screens or Figma (optional)" value="'+e(draft.link)+'" inputmode="url">'+
  '<div class="row" role="group" aria-label="Urgency">'+["Flexible","This week","Urgent"].map(u=>'<button class="chip '+(draft.urgency===u?"on":"")+'" data-urg="'+u+'">'+u+"</button>").join("")+"</div>"+
  '<input id="nm" aria-label="Your name" placeholder="Your name" value="'+e(draft.name)+'" autocomplete="name">'+
  '<button class="btn" data-create="1" '+(ok?"":"disabled")+">Send to Ahmed</button>"+
  (ok?'<div class="card"><b>What happens next</b><span class="sub">1. Ahmed reads it. 2. You get a proposal with price and date. 3. You approve and chat.</span></div>':'<p class="sm" style="margin:-8px 0 0;text-align:center">Pick a help type and write at least 20 characters to continue.</p>');
}
function profile(){
  return '<div class="orb" style="margin:8px auto;width:72px;height:72px;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:#0A0A0A">'+e((draft.name||"You")[0].toUpperCase())+"</div>"+
  '<input id="nm" aria-label="Your name" placeholder="Your name" value="'+e(draft.name)+'">'+
  '<div class="card"><b>About Ahmed</b><span class="sub">UI/UX designer and researcher. I turn user problems into clear, usable products.</span><button class="btn sec" data-page="portfolio">Explore portfolio</button><a href="mailto:ahmedsheraz227@gmail.com">ahmedsheraz227@gmail.com</a></div>'+
  '<div class="card"><b>Workspace shortcuts</b><button class="chip" data-tab="saved">♡ Saved designs</button><button class="chip" data-tab="updates">◌ Notifications</button></div>'+
  '<div class="card"><b>How it works</b><span class="sub">1. Describe your problem. 2. Ahmed sends a proposal. 3. Chat, review the result, approve.</span></div>'+
  '<div class="card"><b>Replies</b><span class="sub">Ahmed usually replies within a day. New updates appear in Notifications.</span></div><button class="btn sec" data-logout="1">Log out</button>';
}
function settings(){
  return '<h1>My <b>settings</b></h1><div class="card"><div class="row between"><b>Accepting new requests</b><button class="tog '+(avail?"on":"")+'" data-avail="1" role="switch" aria-checked="'+avail+'" aria-label="Accepting new requests"></button></div><span class="sm">Clients see Available or Busy on their home screen.</span></div><div class="card"><b>Quick replies</b>'+QUICK.map(q=>'<span class="sub">• '+e(q)+"</span>").join("")+"</div>"+(db?"":'<p class="sm">Preview mode: changes are not shared.</p>')+'<button class="btn sec" data-logout="1">Log out</button>';
}
function loginScreen(){
  const lock=db&&!owner&&!window.DH_STANDALONE;
  return '<div class="orb" style="margin:16px 0 0"></div><h1>Welcome <b>back</b></h1><p class="sub" style="margin:0">Log in to follow your requests. Ahmed signs in as admin to manage them.</p><input id="nm" aria-label="Your name" placeholder="Your name" value="'+e(draft.name)+'" autocomplete="name"><button class="btn" data-login="client">Continue as client</button><div class="sm" style="text-align:center">or</div>'+(window.DH_STANDALONE&&!owner?'<input id="pin" type="password" aria-label="Admin PIN" placeholder="Admin PIN (admin only)" autocomplete="off">':"")+'<button class="btn sec" data-login="admin"'+(lock?" disabled":"")+'>Admin sign in</button><p class="sm" style="margin:0;text-align:center">'+(lock?"The admin area is only for Ahmed.":"Admin access is only for Ahmed.")+"</p>";
}
function outScreen(){return '<div class="orb"></div><h1>You’re signed <b>out</b></h1><p class="sub" style="margin:0">Your requests stay saved. Log back in anytime to pick up where you left off.</p><button class="btn" data-again="1">Log in again</button>'}
function sheet(){
  const adm=session==="admin";
  return '<div class="sheet-bg"><div class="sheet" role="dialog" aria-modal="true" aria-label="Log out"><h2>Log out'+(adm?" of admin":"")+'?</h2><p class="sub" style="margin:0">'+(adm?"New requests will wait for you. Clients are not notified.":"Your requests stay saved. You can log back in anytime.")+'</p><button class="btn" data-confirmout="1">Log out</button><button class="btn sec" data-closeout="1">Stay logged in</button></div></div>';
}
function intro_(){return '<div class="orb"></div><h1>Got a design <b>problem?</b></h1><p class="sub">Talk directly to Ahmed. Share the problem, chat, get real solutions.</p><div class="card"><span>✓ A real designer, no bots</span><span>✓ Clear status for every request</span><span>✓ Replies within about a day</span></div><button class="btn" data-start="1">Get started</button>'}
function render(){
  const keep={};["msg","txt","nm","lk","pr_price","pr_del","pin"].forEach(i=>{const x=document.getElementById(i);if(x)keep[i]=x.value});
  const act=document.activeElement&&document.activeElement.id,pos=document.activeElement&&document.activeElement.selectionStart;
  const adm=isAdmin(),r=open&&reqs.find(x=>x.id===open),mine=reqs.filter(x=>x.owner===me||!db);
  const toggle="";
  let body,tabs="";
  if(!session)body=justOut?outScreen():loginScreen();
  else{
    if(r)body=thread(r,adm);
    else if(adm){
      if(tab==="set")body=settings();
      else{const n=reqs.filter(x=>x.status==="new").length;body='<h1>Client <b>requests</b></h1><p class="sub" style="margin:0">'+n+" new · "+reqs.length+" total</p>"+filters()+list(flt([...reqs]).sort((a,b)=>(a.status==="new"?0:1)-(b.status==="new"?0:1)||b.updatedAt-a.updatedAt),true)}
    }else if(formOpen&&tab==="home")body=formScreen();
    else if(tab==="portfolio")body=portfolioPage();
    else if(tab==="saved")body=savedPage();
    else if(tab==="updates")body=notificationsPage();
    else body=tab==="reqs"?'<h1>My <b>requests</b></h1>'+filters()+list(flt(mine),false):tab==="me"?profile():home(mine);
    const T=adm?[["inbox","Inbox"],["set","Settings"]]:[["home","Home"],["reqs","Requests"],["saved","Saved"],["updates","Updates"],["me","Profile"]];
    const cur=adm?(tab==="set"?"set":"inbox"):tab;
    const dotN=(adm?reqs:mine).some(unread),noticeDot=unreadNoticeCount()>0;
    tabs='<nav class="tabs" aria-label="Main">'+T.map(([k,l])=>'<button data-tab="'+k+'" class="'+(cur===k&&!r?"on":"")+'">'+l+((k==="reqs"||k==="inbox")&&dotN?' <span class="dot"></span>':k==="updates"&&noticeDot?' <span class="dot"></span>':"")+"</button>").join("")+"</nav>";
  }
  const off=navigator.onLine===false?'<div class="off" role="alert">You’re offline. Your draft stays on this phone.</div>':"";
  $.innerHTML='<div class="row between app-topline" style="padding-right:52px"><b>Design Help</b><span class="sm">Ahmed Sheraz</span><button type="button" class="installbtn" data-install-app>Install</button></div>'+off+toggle+body+tabs+(outConfirm?sheet():"");
  Object.entries(keep).forEach(([i,v])=>{const x=document.getElementById(i);if(x)x.value=v});
  if(act){const x=document.getElementById(act);if(x){x.focus();try{x.setSelectionRange(pos,pos)}catch(z){}}}
}
$.addEventListener("click",ev=>{
  const t=ev.target.closest("button");if(!t)return;const d=t.dataset,adm=isAdmin();
  if(d.login){
    if(d.login==="admin"){if(window.DH_STANDALONE&&!owner){const p=(document.getElementById("pin")||{}).value||"";if(p!==(window.DH_CONFIG||{}).adminPin)return toast("Wrong admin PIN.");owner=true;ls.set("dh_admin_ok","1")}
    if(!(owner||!db))return toast("The admin area is only for Ahmed.");session="admin";view="admin";tab="inbox"}
    else{session="client";view="client";tab="home"}
    ls.set("dh_role",session);ls.set("dh_name",draft.name);justOut=false;open=null;formOpen=false;render();window.scrollTo(0,0)}
  else if(d.logout){outConfirm=true;render()}
  else if(d.closeout){outConfirm=false;render()}
  else if(d.confirmout){if(window.DH_STANDALONE&&session==="admin"){owner=false;ls.set("dh_admin_ok","")}ls.set("dh_role","");session="";view="client";tab="home";open=null;formOpen=false;outConfirm=false;justOut=true;render();window.scrollTo(0,0)}
  else if(d.again){justOut=false;render()}
  else if(d.tab){tab=d.tab;open=null;formOpen=false;if(tab==="updates")markAllNoticesRead();render()}
  else if(d.page){tab=d.page;open=null;formOpen=false;render();window.scrollTo(0,0)}
  else if(d.saveDesign){toggleSaved(d.saveDesign)}
  else if(d.markread){markAllNoticesRead();render()}
  else if(d.openNotice){const n=notices().find(x=>x.id===d.openNotice);if(n){const all=notices().map(x=>x.id===n.id?{...x,read:true}:x);ls.set(NOTICES_KEY,JSON.stringify(all));if(n.requestId&&reqs.some(x=>x.id===n.requestId)){tab=session==="admin"?"inbox":"reqs";openReq(n.requestId)}else render()}}
  else if(d.act){const a=ACTS[+d.act];draft.cat=a[3];formOpen=true;render();window.scrollTo(0,0)}
  else if(d.ex){draft.text=EX[+d.ex];const t=document.getElementById("txt");if(t)t.value=draft.text;render()}
  else if(d.closeform){formOpen=false;render()}
  else if(d.start){intro=false;ls.set("dh_intro","1");render()}
  else if(d.cat){draft.cat=d.cat;render()}
  else if(d.urg){draft.urgency=d.urg;render()}
  else if(d.filter){filter=d.filter;render()}
  else if(d.create)create();
  else if(d.open)openReq(d.open);
  else if(d.back){open=null;render()}
  else if(d.avail){avail=!avail;render();if(db)db.doc("settings/ahmed").set({available:avail}).catch(()=>toast("Couldn’t save."))}
  else if(d.prop){prop=true;render()}
  else if(d.sendprop){const p=document.getElementById("pr_price").value.trim(),v=document.getElementById("pr_del").value.trim();if(!p||!v)return toast("Add a price and delivery date.");prop=false;say(open,"ahmed","Proposal sent: "+p+", delivery "+v+".",{status:"accepted",proposal:{price:p,delivery:v}})}
  else if(d.status){const s=d.status;say(open,role(),s==="solved"?"Approved. Thank you!":s==="designing"?"Proposal approved. Let’s start!":"Status: "+LB[s],{status:s})}
  else if(d.changes)say(open,"client","I’d like some changes.",{status:"designing"});
  else if(d.quick)say(open,"ahmed",QUICK[+d.quick]);
  else if(d.slot){const s=SLOTS[+d.slot];say(open,"client","Call request: "+s,{call:s,callOk:false})}
  else if(d.callok)say(open,"ahmed","Call confirmed: "+reqs.find(x=>x.id===open).call,{callOk:true});
  else if(d.attach){const f=document.getElementById("file");if(f)f.click()}
  else if(d.rate)save(open,{rating:+d.rate});
});
$.addEventListener("change",ev=>{if(ev.target.id==="file"){const f=ev.target.files[0];ev.target.value="";attach(f)}});
$.addEventListener("input",ev=>{const i=ev.target.id;if(i==="txt"){draft.text=ev.target.value;const b=$.querySelector("[data-create]");if(b)b.disabled=!(draft.cat&&draft.text.trim().length>=20)}if(i==="nm"){draft.name=ev.target.value;ls.set("dh_name",draft.name)}if(i==="lk")draft.link=ev.target.value});
$.addEventListener("submit",ev=>{ev.preventDefault();const i=ev.target.querySelector("input"),v=i.value.trim();if(!v)return;i.value="";say(open,role(),v)});
addEventListener("online",render);addEventListener("offline",render);
const SUN='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',MOON='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>';
let theme=ls.get("dh_theme")==="light"?"light":"dark";
function applyTheme(t){theme=t;document.documentElement.dataset.theme=t;const b=document.getElementById("theme");b.innerHTML=t==="dark"?SUN:MOON;b.setAttribute("aria-label",t==="dark"?"Switch to light mode":"Switch to dark mode");ls.set("dh_theme",t)}
document.getElementById("theme").addEventListener("click",()=>applyTheme(theme==="dark"?"light":"dark"));
applyTheme(theme);
render();
(async()=>{
  if(!window.claude)return;
  const user=await claude.use("user"),d=await claude.use("db");
  if(!d)return;try{assets=await claude.use("assets")}catch(x){}
  db=d;try{me=String(await user.id())}catch(x){me="anon"}
  owner=!!(user&&user.isOwner());if(session==="admin"&&!owner){session="";ls.set("dh_role","")}view=session==="admin"?"admin":"client";tab=session==="admin"?"inbox":"home";
  db.collection("requests").orderBy("createdAt","desc").limit(200).onSnapshot(s=>{reqs=s.docs.map(x=>({id:x.id,...x.data()}));render()},()=>toast("Live updates paused."));
  db.doc("settings/ahmed").onSnapshot(s=>{avail=s.exists?s.data().available!==false:true;render()},()=>{});
  render();
})();
