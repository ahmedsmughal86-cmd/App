# Design Help — Start Here

This is the expanded interactive Design Help prototype by Ahmed Sheraz. It includes the client app, admin workspace, a gallery of 88 screen concepts, a portfolio page, saved designs, and in-app notifications.

## Start on macOS (one click)

1. Extract `Design-Help-Expanded-Mac-Ready.zip`.
2. Open the extracted `design-help-project` folder.
3. Double-click `start-prototype.command`.
4. The launcher finds an available local port, starts the web server, and opens the app directly in your browser.
5. Keep the Terminal window open while using the prototype. Press **Control + C** to stop it.

If macOS blocks the first launch, Control-click (or right-click) `start-prototype.command`, choose **Open**, then confirm.

## Start manually (Mac / Linux)

Open Terminal in this folder and run:

```bash
python3 -m http.server 8080
```

Then open <http://127.0.0.1:8080/app/>.

## Start on Windows

Double-click `start-prototype.bat`. It starts the local server and opens the app in your default browser.

## Demo sign-in

- Client: enter any name and select **Continue as client**.
- Admin: use the demo PIN `1234` and select **Admin sign in**.
- Change the demo PIN in `app/config.js` before sharing the project. It is a front-end demo lock, not production authentication.

## New features in this version

- Expanded service menu: UX audit, web and mobile UI, Figma review, motion and animation, design systems, accessibility, research and more.
- Portfolio: six featured concepts link to the matching original screens in the included 88-screen gallery.
- Saved Designs: bookmark portfolio concepts with the heart button; saved items remain in this browser.
- Notifications: request creation and client/designer messages create in-app activity updates. Notifications can be marked as read and open their related request.
- Existing request flow remains: proposals, status tracking, chat, attachments, call requests, delivery approval, changes and ratings.

## Important prototype limitations

- The app is a browser-based prototype. Requests and messages use the included local runtime and browser storage; saved designs and notifications use `localStorage`.
- Local data is not a shared account or cloud database. Other devices and other browser profiles will not see it.
- The demo admin PIN is in client-side JavaScript. Do not use it to protect real client data.
- Real multi-user use requires hosted authentication, a cloud database, server-side authorization, and cloud file storage.

## Project entry points

- `index.html` — project landing page and links to the app and screen gallery.
- `app/index.html` — interactive client/admin prototype.
- `screens/index.html` — gallery of 88 design screens.
- `app/app.js` — client-side app behavior and expanded feature set.
- `app/styles.css` — responsive visual system (black, neon lime and purple).


## Mobile app

- Android/iPhone Home Screen installation: publish over HTTPS and follow `MOBILE-APP-GUIDE.md`.
- Native Android project: double-click `open-android.command` on Mac (or use the documented npm commands on Windows).
- Native iPhone project: double-click `open-ios.command` on a Mac with Xcode installed.
