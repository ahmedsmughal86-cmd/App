#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

if [ "$(uname -s)" != "Darwin" ]; then echo "iOS builds must be prepared on macOS with Xcode."; read -r -p "Press Return to close..."; exit 1; fi
if ! command -v node >/dev/null 2>&1; then echo "Install Node.js 22+ first: https://nodejs.org/"; read -r -p "Press Return to close..."; exit 1; fi
NODE_MAJOR=$(node -p 'Number(process.versions.node.split(".")[0])')
if [ "$NODE_MAJOR" -lt 22 ]; then echo "Capacitor 8 requires Node.js 22 or later. Current: $(node -v)"; read -r -p "Press Return to close..."; exit 1; fi
if ! xcode-select -p >/dev/null 2>&1; then echo "Install Xcode and Xcode Command Line Tools first."; read -r -p "Press Return to close..."; exit 1; fi
echo "Installing mobile app tools..."
npm install
if [ ! -d ios ]; then npx cap add ios; fi
npx cap sync ios
npx cap open ios
