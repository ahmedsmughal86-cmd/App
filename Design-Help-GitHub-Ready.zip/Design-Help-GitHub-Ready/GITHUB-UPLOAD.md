# Upload this project to GitHub

## Easiest method — GitHub website

1. Sign in to GitHub and create a new repository named `design-help`.
2. Choose Public if you want GitHub Pages on the free plan.
3. Open the new empty repository and choose **Add file → Upload files**.
4. Open the extracted project folder on your computer and drag all of its contents into the GitHub upload area. Upload the files inside this folder, including the `.github` folder; do not upload only the ZIP file.
5. Add the commit message `Add Design Help prototype` and choose **Commit changes**.
6. Open **Settings → Pages** and choose **GitHub Actions** as the source.
7. The included workflow deploys the site automatically after the next push to `main`.

## Git command method

```bash
git init
git add .
git commit -m "Initial Design Help prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/design-help.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

Then enable **Settings → Pages → Source: GitHub Actions**. Check the **Actions** tab for deployment status.
