# Design Help — GitHub-ready mobile-first prototype

A responsive, installable web app / PWA for Design Help by Ahmed Sheraz. The repository includes the client experience, admin workspace, an 88-screen concept gallery, expanded design services, portfolio, saved designs, notifications, and Capacitor scaffolding for Android/iOS packaging.

## Run locally

### macOS
1. Download and extract the ZIP, or clone this repository.
2. Open the project folder.
3. Double-click `start-prototype.command`.
4. The browser opens the app at `/app/`. Keep the Terminal window open while using it.

### Windows
Double-click `start-prototype.bat`.

### Any platform with Python 3

```bash
python3 -m http.server 8080
```

Then open <http://localhost:8080/app/>.

## Demo access

- Client: create a demo profile with any name.
- Admin: demo PIN is `1234`.

The PIN is in `app/config.js` and is visible in browser code. It is a demo convenience only, not secure authentication.

## Deploy from GitHub

### GitHub Pages (automatic)

This repo includes `.github/workflows/deploy-pages.yml`.

1. Create a new **public** GitHub repository, for example `design-help`.
2. Upload the contents of this folder to the repository root (not the enclosing folder), or push with Git:

   ```bash
   git init
   git add .
   git commit -m "Initial Design Help prototype"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/design-help.git
   git push -u origin main
   ```

3. On GitHub, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
4. Open the **Actions** tab. The workflow deploys the site after a push to `main`.
5. When deployment finishes, open the URL shown in the `github-pages` environment.

The app and gallery paths are relative, and the PWA manifest/service worker are configured to support GitHub Pages project URLs as well as domain-root hosting.

### Vercel (connected to GitHub)

1. Push this repository to GitHub using the steps above.
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the `design-help` GitHub repository.
4. Keep **Framework Preset: Other**, **Root Directory: `./`**, and leave Build Command and Output Directory empty/default for this static project.
5. Select **Deploy**. Vercel can automatically redeploy on later commits to the connected branch.

See `DEPLOY-TO-VERCEL.md` for more detail.

## Mobile installation

After deploying to an HTTPS URL:

- **Android:** open the site in Chrome and choose **Install app** / **Add to Home screen**.
- **iPhone:** open the site in Safari → Share → **Add to Home Screen**.

For native Android/iOS project scaffolding and Capacitor instructions, see `MOBILE-APP-GUIDE.md`.

## Project entry points

- `index.html` — project landing page.
- `app/` — interactive client/admin prototype.
- `screens/` — gallery of 88 screen concepts.
- `design-system/` — design tokens and canvas layout data.
- `manifest.webmanifest`, `sw.js`, `icons/` — PWA install and offline support.
- `www/` — Capacitor web bundle.

## Prototype limitations

This is a front-end prototype. Requests, saved designs and notifications use browser storage and remain local to the current browser/device. They are not shared across real client accounts. Before accepting customer data, add a backend with secure authentication, server-side authorization, a shared database and cloud file storage. Never use the client-side demo PIN to protect real customer information.
