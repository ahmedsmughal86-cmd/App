# Publish the Design Help demo with Netlify

The project is a static site; it does not need a build command.

1. Extract the project ZIP.
2. Open <https://app.netlify.com/drop> and sign in to your Netlify account.
3. Drag the complete `design-help-project` folder onto the drop area.
4. Netlify will publish the site and provide a generated `*.netlify.app` URL.
5. Open the site URL, then choose **Launch the app** on the landing page, or go directly to `/app/`.

The 88-screen gallery is available at `/screens/`.

## Important

This publishes the static front end only. Requests, saved designs and notifications remain local to each visitor's browser because this prototype uses browser storage. To let different clients and Ahmed share real requests and messages, connect a production backend with authentication, database rules, and cloud file storage first. The demo admin PIN is not security.
