// Scope-relative service worker: supports both Vercel root domains and GitHub Pages project paths.
const CACHE_NAME = "design-help-mobile-github-v2";
const BASE_URL = new URL(self.registration.scope);
const PRECACHE_PATHS = [
  "",
  "app/",
  "app/index.html",
  "app/styles.css",
  "app/app.js",
  "app/config.js",
  "app/runtime.js",
  "app/pwa.js",
  "screens/",
  "screens/index.html",
  "manifest.webmanifest",
  "icons/design-help-192.png",
  "icons/design-help-512.png",
  "icons/design-help-maskable-512.png",
  "icons/apple-touch-icon.png",
  "screens/About.html",
  "screens/Admin1.html",
  "screens/Admin10.html",
  "screens/Admin2.html",
  "screens/Admin3.html",
  "screens/Admin4.html",
  "screens/Admin5.html",
  "screens/Admin6.html",
  "screens/Admin7.html",
  "screens/Admin8.html",
  "screens/Admin9.html",
  "screens/CV.html",
  "screens/Contact.html",
  "screens/DS1.html",
  "screens/Detail.html",
  "screens/Edu.html",
  "screens/Exp.html",
  "screens/Home.html",
  "screens/L1.html",
  "screens/L2.html",
  "screens/L3.html",
  "screens/L4.html",
  "screens/L5.html",
  "screens/L6.html",
  "screens/Main.html",
  "screens/Skills.html",
  "screens/V2C1.html",
  "screens/V2C10.html",
  "screens/V2C11.html",
  "screens/V2C12.html",
  "screens/V2C2.html",
  "screens/V2C3.html",
  "screens/V2C4.html",
  "screens/V2C5.html",
  "screens/V2C6.html",
  "screens/V2C7.html",
  "screens/V2C8.html",
  "screens/V2C9.html",
  "screens/V3A.html",
  "screens/V3B.html",
  "screens/V3C.html",
  "screens/V3D.html",
  "screens/V3E.html",
  "screens/V3F.html",
  "screens/V3G.html",
  "screens/WK1.html",
  "screens/WK2.html",
  "screens/WK3.html",
  "screens/WK4.html",
  "screens/WU1.html",
  "screens/WU2.html",
  "screens/WU3.html",
  "screens/WUF.html",
  "screens/WY1.html",
  "screens/WY10.html",
  "screens/WY11.html",
  "screens/WY12.html",
  "screens/WY13.html",
  "screens/WY2.html",
  "screens/WY3.html",
  "screens/WY4.html",
  "screens/WY5.html",
  "screens/WY6.html",
  "screens/WY7.html",
  "screens/WY8.html",
  "screens/WY9.html",
  "screens/WZ1.html",
  "screens/WZ2.html",
  "screens/WZ3.html",
  "screens/WZ4.html",
  "screens/WZ5.html",
  "screens/WZ6.html",
  "screens/WZ7.html",
  "screens/WZ8.html",
  "screens/Work.html",
  "screens/XM1.html",
  "screens/XM2.html",
  "screens/XM3.html",
  "screens/XM4.html",
  "screens/XN1.html",
  "screens/XN2.html",
  "screens/XN3.html",
  "screens/XN4.html",
  "screens/XV1.html",
  "screens/XV2.html",
  "screens/XV3.html",
  "screens/XV4.html",
  "screens/XV5.html",
  "screens/index.html"
];
const PRECACHE_URLS = PRECACHE_PATHS.map(path => new URL(path, BASE_URL).href);
const APP_URL = new URL("app/", BASE_URL).href;

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith(
    fetch(request).then(response => {
      if (response && response.status === 200 && response.type === "basic") {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
      }
      return response;
    }).catch(() => caches.match(request).then(cached => cached || (request.mode === "navigate" ? caches.match(APP_URL) : undefined)))
  );
});
