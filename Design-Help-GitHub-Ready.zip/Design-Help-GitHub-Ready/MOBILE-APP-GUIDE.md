# Design Help — Mobile App Guide

This project now supports two mobile routes:

1. **Installable mobile web app (PWA):** publish the project over HTTPS, then install it from Android Chrome or add it to the iPhone Home Screen using Safari. It opens in a standalone app window and caches the app and included screen gallery for offline viewing after the first successful load.
2. **Native Android/iOS wrapper:** Capacitor packages the same app UI inside a native Android or iOS shell. It preserves the existing app screens and local prototype behavior.

## A. Install on Android / iPhone without app stores

1. Publish the complete `design-help-project` folder to an HTTPS static host (Netlify Drop, Cloudflare Pages or another static host). Do not upload only the `app` folder; the `screens`, `icons`, `manifest.webmanifest` and `sw.js` files are needed.
2. On **Android**, open the live URL in Chrome, open the browser menu and choose **Install app** / **Add to Home screen**. On supported browsers, the app also displays an Install button.
3. On **iPhone**, open the live URL in Safari → Share → **Add to Home Screen** → Add.
4. Launch Design Help from the new Home Screen icon.

A live HTTPS URL is required for PWA installation and service-worker offline support. The app's current data is still stored locally on that device/browser; it is not shared across clients.

## B. Build an Android app (APK) on Mac or Windows

Prerequisites: Node.js 22+, Android Studio 2025.2.1 or later, and an Android SDK. Android Studio includes the required JDK.

On macOS, double-click `open-android.command`. Or run:

```bash
npm install
npx cap add android       # only the first time
npx cap sync android
npx cap open android
```

In Android Studio, connect an Android phone or start an emulator, select the device and press **Run**. To create a test APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. For a release/Play Store build, configure signing and Play Console details.

## C. Build an iPhone app (iOS) on Mac

Prerequisites: macOS, Node.js 22+, Xcode 26 or later, and Xcode Command Line Tools.

Double-click `open-ios.command`. Or run:

```bash
npm install
npx cap add ios          # only the first time
npx cap sync ios
npx cap open ios
```

In Xcode, select an iPhone simulator or connected iPhone and press **Run**. App Store / TestFlight distribution requires Apple signing and the relevant Apple Developer account setup.

## D. Updating the mobile bundle

If you change files in `app/` or `screens/`, copy them into `www/` (the same folder structure) before running `npx cap sync`. Then open the Android or iOS project again. The supplied `www/` directory is already populated with the current mobile app.

## What's included

- Existing Design Help expanded UI and client/admin prototype flows.
- Mobile viewport and safe-area support.
- Installable PWA manifest, icons, install instructions and service worker.
- Offline cache for the app shell and included screen gallery after first load.
- Capacitor 8 Android/iOS wrapper configuration.
- Mac helper scripts to generate/sync and open Android Studio or Xcode projects.

## Important limitations

- This download is a **mobile app source package**, not a compiled APK or signed iOS IPA. Android Studio / Xcode must build those native files on a correctly configured development machine.
- Local prototype data remains local to each browser/app installation. Real multi-user accounts, shared messages, cloud uploads, push notifications and secure admin access need a backend and production security rules.
- The demo admin PIN is front-end demo gating only; do not use it to protect real customer data.

## Official tool requirements

- Capacitor install: https://capacitorjs.com/docs/getting-started
- Capacitor environment setup: https://capacitorjs.com/docs/getting-started/environment-setup
- Android: https://capacitorjs.com/docs/android
- iOS: https://capacitorjs.com/docs/ios
